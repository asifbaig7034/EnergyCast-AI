
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "processed" / "dashboard_data.csv"
PERFORMANCE_FILE = ROOT / "reports" / "model_performance.csv"
BACKTEST_FILE = ROOT / "reports" / "trading_backtest.csv"

st.set_page_config(
    page_title="EnergyCast AI",
    page_icon="⚡",
    layout="wide",
)

st.title("⚡ EnergyCast AI")
st.caption(
    "Electricity-market forecasting and trading research | "
    "Historical data and experimental model results"
)

@st.cache_data
def load_data():
    data = pd.read_csv(DATA_FILE, parse_dates=["timestamp"])
    metrics = pd.read_csv(PERFORMANCE_FILE)
    backtest = pd.read_csv(BACKTEST_FILE)

    if "Unnamed: 0" in backtest.columns:
        backtest = backtest.rename(columns={"Unnamed: 0": "timestamp"})
    elif "timestamp" not in backtest.columns:
        backtest = backtest.rename(columns={backtest.columns[0]: "timestamp"})

    backtest["timestamp"] = pd.to_datetime(
        backtest["timestamp"], utc=True, errors="coerce"
    )
    data["timestamp"] = pd.to_datetime(
        data["timestamp"], utc=True, errors="coerce"
    )
    return data, metrics, backtest

try:
    data, metrics, backtest = load_data()
except Exception as exc:
    st.error("Could not load the dashboard data files.")
    st.info(
        "Ensure data/processed/dashboard_data.csv, "
        "reports/model_performance.csv, and "
        "reports/trading_backtest.csv exist beside app.py."
    )
    st.exception(exc)
    st.stop()

required = [
    "electricity_demand_mw",
    "wind_generation_mw",
    "price_eur_mwh",
]
missing = [col for col in required if col not in data.columns]
if missing:
    st.error(f"Required data columns are missing: {missing}")
    st.stop()

st.sidebar.header("Dashboard controls")
metric_options = {
    "Electricity demand (MW)": "electricity_demand_mw",
    "Wind generation (MW)": "wind_generation_mw",
    "Day-ahead price (EUR/MWh)": "price_eur_mwh",
}

selected_metric = st.sidebar.selectbox(
    "Historical metric",
    options=list(metric_options.keys()),
)
series_choice = metric_options[selected_metric]

min_date = data["timestamp"].min().date()
max_date = data["timestamp"].max().date()
date_range = st.sidebar.date_input(
    "Date range",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
)

filtered = data.copy()
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start_date, end_date = date_range
    filtered = filtered[
        filtered["timestamp"].dt.date.between(start_date, end_date)
    ]

c1, c2, c3 = st.columns(3)
c1.metric("Hourly observations", f"{len(filtered):,}")
c2.metric(
    "Average demand",
    f"{filtered['electricity_demand_mw'].mean():,.0f} MW"
    if filtered["electricity_demand_mw"].notna().any() else "N/A",
)
c3.metric(
    "Average market price",
    f"€{filtered['price_eur_mwh'].mean():,.2f}/MWh"
    if filtered["price_eur_mwh"].notna().any() else "N/A",
)

st.subheader("Historical market data")
fig = px.line(
    filtered,
    x="timestamp",
    y=series_choice,
    title="Selected metric over time",
    labels={"timestamp": "Timestamp (UTC)", series_choice: "Value"},
)
fig.update_layout(hovermode="x unified")
st.plotly_chart(fig, use_container_width=True)

st.subheader("Forecast model evaluation")
st.caption(
    "Metrics come from the notebook's held-out test period. "
    "They are historical evaluation results, not a guarantee of future accuracy."
)
if {"Model", "MAE", "RMSE", "Unit"}.issubset(metrics.columns):
    st.dataframe(metrics, use_container_width=True, hide_index=True)
else:
    st.warning("The model-performance file has an unexpected format.")
    st.dataframe(metrics, use_container_width=True)

st.subheader("Trading backtest")
if "net_pnl_eur" in backtest.columns:
    total_pnl = backtest["net_pnl_eur"].sum()
    n_positions = (
        int((backtest["position"] != 0).sum())
        if "position" in backtest.columns else 0
    )
    b1, b2 = st.columns(2)
    b1.metric("Net simulated P&L", f"€{total_pnl:,.2f}")
    b2.metric("Non-zero position periods", f"{n_positions:,}")

    if "cumulative_pnl_eur" in backtest.columns:
        pnl_fig = px.line(
            backtest,
            x="timestamp",
            y="cumulative_pnl_eur",
            title="Cumulative simulated net P&L",
            labels={
                "timestamp": "Forecast origin (UTC)",
                "cumulative_pnl_eur": "Cumulative P&L (€)",
            },
        )
        pnl_fig.add_hline(y=0, line_dash="dash")
        st.plotly_chart(pnl_fig, use_container_width=True)

    st.caption(
        "Research simulation only. The initial strategy uses simplified "
        "execution assumptions and overlapping positions. Results are not "
        "live-trading performance and do not establish future profitability."
    )
else:
    st.warning("Net P&L is unavailable in the backtest file.")

with st.expander("View recent market data"):
    st.dataframe(filtered.tail(100), use_container_width=True, hide_index=True)

st.divider()
st.caption(
    "EnergyCast AI | Portfolio research prototype | "
    "Historical dataset, experimental forecasts, and simplified backtesting"
)
